package minesweeper;

import static java.awt.Color.GREEN;
import static java.awt.Color.RED;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;


public class toplista extends JFrame {

	
			
	public adatokData data;
	JTextField nameField = new JTextField(20); //ahol nev szerint lehet keresni
	
	private void initComponents() {
        this.setLayout(new BorderLayout());


        JTable table = new JTable(data); //UJ TABLAZAT KOMPONENS
        JScrollPane scrollPane = new JScrollPane(table); //LAPOZHATO PANEL
        table.setFillsViewportHeight(true); //AZ EGESZ ABLAKOT KITOLTI
        add(scrollPane, BorderLayout.CENTER); //KOZEPSO TERULETRE
        
        JPanel addStud = new JPanel();

        JButton button = new JButton("Keres");
        button.addActionListener(new AddButtonListener());
        addStud.add(new JLabel("Név:"));
        addStud.add(nameField);
        addStud.add(button);
        add(addStud, BorderLayout.SOUTH);

        table.setRowSorter(new TableRowSorter<>(table.getModel()));
        
        table.setDefaultRenderer(String.class, new StudentTableCellRenderer(table.getDefaultRenderer(String.class)));
        table.setDefaultRenderer(Integer.class, new StudentTableCellRenderer(table.getDefaultRenderer(Integer.class)));
        table.setDefaultRenderer(Integer.class, new StudentTableCellRenderer(table.getDefaultRenderer(Integer.class)));
	}
	
	final class AddButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
        }
    }
	
	class StudentTableCellRenderer implements TableCellRenderer {

        private TableCellRenderer renderer;

        public StudentTableCellRenderer(TableCellRenderer defRenderer) {
            this.renderer = defRenderer;
        } 

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,int row, int column) {
			Component component = renderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if(((Integer)(data.getValueAt(table.getRowSorter().convertRowIndexToModel(row), 3)))== 0) {
                component.setBackground(RED);
            }else{
                component.setBackground(GREEN);
            }

            return component;
        }
		}
        
	
	 //Az ablak konstruktora
    @SuppressWarnings("unchecked")
    
    public toplista(adatokData dataa) {
        super("Toplista");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        data = dataa;
        /*
        
        // Induláskor betöltjük az adatokat
        try {
            data = new adatokData();
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("toplista.txt"));
            data.adatok = (List<adatoktoplistaba>)ois.readObject();
            //data.addadatoktoplistaba("Imre", 5, 1000);
            ois.close();
            
        } catch(Exception ex) {
            ex.printStackTrace();
        } 
        */
        
        // Bezáráskor mentjük az adatokat
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("toplista.txt"));
                    oos.writeObject(data.adatok);
                    oos.close();
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Felépítjük az ablakot
        setMinimumSize(new Dimension(525, 250));
        initComponents();
    }
      
}
