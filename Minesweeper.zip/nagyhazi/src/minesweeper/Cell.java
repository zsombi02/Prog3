package minesweeper;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

public class Cell extends JButton { //ez az osztály egy mezőt határoz meg

    private int type;
    private int position;
    private boolean discovered;
    private boolean flagged;

    private Handler handler;

    public Cell(int type, int position, boolean discovered, boolean flagged, Handler handler) {
        this.type = type;
        this.position = position;
        this.discovered = discovered;
        this.flagged = flagged;
        this.handler = handler;

        addMouseListener((MouseListener) new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(SwingUtilities.isRightMouseButton(e)) {
                    rightClickButton();
                } else {
                    clickButton();
                }
            }

            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
        });
    }

    public int getType() {
        //típusok: 0:üres, 1:akna van azon a mezőn, 2:szám
        return type;
    }

    public int getPosition() { //hol van
        return position;
    }

    public boolean isDiscovered() { //fel lett-e fedezve eddig
        return discovered;
    }

    public void setDiscovered(boolean d) { //fel lett fedezve, ezért átállítani felfedezettre
        this.discovered = d;
    }

    public boolean isFlagged() { //jobb klikkel zászlózták
        return flagged;
    }

    public void setFlagged(boolean f) { //beállítani f betűsre
        this.flagged = f;
    }

    public void clickButton() {
        handler.click(this);
    }

    public void rightClickButton() { //j
        handler.rightClick(this);
    }
}