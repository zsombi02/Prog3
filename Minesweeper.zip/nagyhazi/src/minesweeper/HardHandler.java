package minesweeper;

import java.util.ArrayList;

public class HardHandler {

	 private ArrayList<HardCell> current = new ArrayList<HardCell>();
	    private ArrayList<HardCell> queue = new ArrayList<HardCell>();
	   
	    private static int flaggedCells = 0;
	    long timepassed =0;
	    public long kezdoido = System.currentTimeMillis();
	    public long vegido;
	    boolean won;
	    adatokData dataa;
	    String name;
	    
	    public HardHandler(adatokData data, String nev) {
			dataa = data;
			name = nev;
		}

		public boolean getWon()
	    {	return this.won;}
	    
	    public long getTimepassed()
	    {	return this.timepassed;}
	    
	    
	    public void click(HardCell hardCell) {
	        int discoveredCells = 0;
	        if(!hardCell.isFlagged()) {
	            hardCell.setEnabled(false);
	            hardCell.setDiscovered(true);

	            int position = hardCell.getPosition();
	            if(hardCell.getType() == 0) {
	                if(position < HardGame.GRIDSIZE) {
	                    if(position % HardGame.GRIDSIZE == 0) {
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE + 1)));
	                        queue.add(HardGrid.cellGrid.get((position + 1)));
	                    } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)));
	                        queue.add(HardGrid.cellGrid.get((position - 1)));
	                    } else {
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE + 1)));
	                        queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)));
	                        queue.add(HardGrid.cellGrid.get((position + 1)));
	                        queue.add(HardGrid.cellGrid.get((position - 1)));
	                    }
	                } else if(position >= (HardGame.GRIDSIZE * (HardGame.GRIDSIZE - 1))) {
	                    if(position % HardGame.GRIDSIZE == 0) {
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE + 1)));
	                        queue.add(HardGrid.cellGrid.get((position + 1)));
	                    } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)));
	                        queue.add(HardGrid.cellGrid.get((position - 1)));
	                    } else {
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE + 1)));
	                        queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)));
	                        queue.add(HardGrid.cellGrid.get((position + 1)));
	                        queue.add(HardGrid.cellGrid.get((position - 1)));
	                    }
	                } else if(position % HardGame.GRIDSIZE == 0) {
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE + 1)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE + 1)));
	                    queue.add(HardGrid.cellGrid.get((position + 1)));
	                } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)));
	                    queue.add(HardGrid.cellGrid.get((position - 1)));
	                } else {
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)));
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)));
	                    queue.add(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE + 1)));
	                    queue.add(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE + 1)));
	                    queue.add(HardGrid.cellGrid.get((position - 1)));
	                    queue.add(HardGrid.cellGrid.get((position + 1)));
	                }
	            } else if(hardCell.getType() == 2) {
	                int dangerCount = 0;
	                if(position < HardGame.GRIDSIZE) {
	                    if(position % HardGame.GRIDSIZE == 0) {
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++; 
	                        if(HardGrid.cellGrid.get(position + 1).getType() == 1) dangerCount++;
	                    } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE - 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - 1).getType() == 1) dangerCount++;
	                    } else {
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE - 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - 1).getType() == 1) dangerCount++;
	                        System.out.println(dangerCount);
	                    }
	                } else if(position >= (HardGame.GRIDSIZE * (HardGame.GRIDSIZE - 1))) {
	                    if(position % HardGame.GRIDSIZE == 0) {
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + 1).getType() == 1) dangerCount++;
	                    } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE - 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - 1).getType() == 1) dangerCount++;
	                    } else {
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE - 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position + 1).getType() == 1) dangerCount++;
	                        if(HardGrid.cellGrid.get(position - 1).getType() == 1) dangerCount++;
	                    }
	                } else if(position % HardGame.GRIDSIZE == 0) {
	                    if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get(position - HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get(position + HardGame.GRIDSIZE + 1).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get(position + 1).getType() == 1) dangerCount++;
	                } else if(position % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1) {
	                    if(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position - 1)).getType() == 1) dangerCount++;
	                } else {
	                    if(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE - 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE - 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position - HardGame.GRIDSIZE + 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + HardGame.GRIDSIZE + 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position - 1)).getType() == 1) dangerCount++;
	                    if(HardGrid.cellGrid.get((position + 1)).getType() == 1) dangerCount++;
	                }
	                hardCell.setText(String.valueOf(dangerCount));
	            } else if(hardCell.getType() == 1) {
	                for(int x = 0; x < HardGrid.cellGrid.size(); x++) {
	                	HardGrid.cellGrid.get(x).setEnabled(false);
	                	HardGrid.cellGrid.get(x).setText("");
	                    if(HardGrid.cellGrid.get(x).getType() == 1) {HardGrid.cellGrid.get(x).setText("X");}
	                }
	                hardCell.setText("*");
	                won = false;
	                gratulalok grat = new gratulalok(dataa, name, won, 0, "nehez");
	            }  

	            for(int x = 0; x < queue.size(); x++) {
	                if(!queue.get(x).isDiscovered()) {
	                    current.add(queue.get(x));
	                    queue.get(x).setDiscovered(true);
	                }
	            }
	            queue.clear();
	            while(!current.isEmpty()) {
	                HardCell temp = current.get(0);
	                current.remove(0);
	                temp.clickButton();
	            }

	            for(int x = 0; x < HardGrid.cellGrid.size(); x++) {
	                if(HardGrid.cellGrid.get(x).isDiscovered()) {
	                    discoveredCells++;
	                }
	            }

	            if(discoveredCells == HardGrid.cellGrid.size() - HardGame.MINECOUNT) {
	                for(int x = 0; x < HardGrid.cellGrid.size(); x++) {
	                    if(HardGrid.cellGrid.get(x).getType() == 1) {
	                    	HardGrid.cellGrid.get(x).setEnabled(false);
	                    	HardGrid.cellGrid.get(x).setText("X");
	                    } else {
	                    	HardGrid.cellGrid.get(x).setEnabled(false);
	                    	HardGrid.cellGrid.get(x).setText(":)");
	                    	vegido = System.currentTimeMillis();
	                    }
	                }
	                won = true;
	                vegido = System.currentTimeMillis();
	                timepassed = Math.subtractExact(vegido, kezdoido);
	                gratulalok grat = new gratulalok(dataa, name, won, timepassed, "nehez");
	            }
	        }   
	    }

	    public void rightClick(HardCell cell) {
	        if(!cell.isDiscovered()) {
	            if(!cell.isFlagged()) {
	                cell.setFlagged(true);
	                cell.setText("F");
	                flaggedCells++;
	                HardWindow.update(flaggedCells);
	            } else {
	                cell.setFlagged(false);
	                cell.setText("");
	                flaggedCells--;
	                HardWindow.update(flaggedCells);
	            }
	        }
	    }
}
