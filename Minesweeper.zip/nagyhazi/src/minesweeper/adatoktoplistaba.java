package minesweeper;

import java.io.Serializable;

public class adatoktoplistaba implements Serializable { //setter, getter fv-ei azon adatoknak, melyek kellenek a toplistaba

	private String nev;
	private String nehezseg;
	private int ido;
	
	public String getnev()
	{
		return this.nev;
	}
	
	public String getnehezseg()
	{
		return this.nehezseg;
	}
	
	public int getido()
	{
		return this.ido;
	}
	
	public void setnev(String nev)
	{
		this.nev = nev;
	}
	
	public void setnehezseg(String nehezseg)
	{
		this.nehezseg = nehezseg;
	}
	
	public void setido(int ido)
	{
		this.ido = ido;
	}
	
	public adatoktoplistaba(String nev, String nehezseg, int ido) //kontruktor
	{
		this.nev = nev;
		this.nehezseg = nehezseg;
		this.ido = ido;
	}
}
