package minesweeper;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

public class HardCell extends JButton{

	 private int type;
	    private int position;
	    private boolean discovered;
	    private boolean flagged;

	    private HardHandler handler;

	    public HardCell(int type, int position, boolean discovered, boolean flagged, HardHandler handler) {
	        this.type = type;
	        this.position = position;
	        this.discovered = discovered;
	        this.flagged = flagged;
	        this.handler = handler;

	        addMouseListener((MouseListener) new MouseListener() {
	            @Override
	            public void mouseClicked(MouseEvent e) {
	                if(SwingUtilities.isRightMouseButton(e)) {
	                    rightClickButton();
	                } else {
	                    clickButton();
	                }
	            }

	            public void mouseEntered(MouseEvent e) {}
	            public void mouseExited(MouseEvent e) {}
	            public void mousePressed(MouseEvent e) {}
	            public void mouseReleased(MouseEvent e) {}
	        });
	    }

	    public int getType() {
	        // TYPES -- 0: Empty, 1: Mine, 2: Number
	        return type;
	    }

	    public int getPosition() {
	        return position;
	    }

	    public boolean isDiscovered() {
	        return discovered;
	    }

	    public void setDiscovered(boolean d) {
	        this.discovered = d;
	    }

	    public boolean isFlagged() {
	        return flagged;
	    }

	    public void setFlagged(boolean f) {
	        this.flagged = f;
	    }

	    public void clickButton() {
	        handler.click(this);
	    }

	    public void rightClickButton() {
	        handler.rightClick(this);
	    }
}
