package minesweeper;

public class HardGame {

	public static final int WIDTH = 720, HEIGHT = 720;
    public static final int GRIDSIZE = 15;
    public static final int MINECOUNT = (int) Math.round(GRIDSIZE * GRIDSIZE * .1);
    //Date date = new Date();

    //private HardHandler handler = new HardHandler();

    public HardGame(adatokData data, String nev) {
    	HardHandler handler = new HardHandler(data, nev);
        new HardWindow(WIDTH, HEIGHT, GRIDSIZE, "Aknakereso - ", this, handler);
        HardWindow.update(0);
    }
}
