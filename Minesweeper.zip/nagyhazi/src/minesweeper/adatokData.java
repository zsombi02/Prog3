package minesweeper;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;


public class adatokData extends AbstractTableModel{

	public List<adatoktoplistaba> adatok = new ArrayList <adatoktoplistaba>();
	
	/*annyi sora lesz, ahány rekord*/
	 public int getRowCount() { 
	        return adatok.size();
	    }
	/*beállítom, hogy 3 ozlopos legyen*/
	 public int getColumnCount() { 
	        return 3;
	    }
	/*az értékeit honnan kapja a táblázat*/
	  public Object getValueAt(int rowIndex, int columnIndex) { 
	        adatoktoplistaba adatoktop = adatok.get(rowIndex);
	        switch(columnIndex){
	            case 0:
	                return adatoktop.getnev();
	            case 1:
	                return adatoktop.getnehezseg();
	           default:
	                return adatoktop.getido();
	        }
	    }
	/*az oszlopok neveinek a beállítása*/
	  public String getColumnName(int column) { 
	        switch(column){
	            case 0:
	                return "Nev";
	            case 1:
	                return "Mod";
	            default:
	                return "Ido";
	        }
	    }
	/*az oszlopok típúsainak a beállítása*/
	  public Class<?> getColumnClass(int columnIndex) { 
	        switch (columnIndex){
	            case 0: 
	            	return String.class;
	            case 1:
	                return String.class;
	            default:
	                return Integer.class;

	        }
	    }
	/*eltarolja az ertekek*/
	  public void setValueAt(Object aValue, int rowIndex, int columnIndex) { 
	    	adatoktoplistaba adatoktop = adatok.get(rowIndex);
	        if(columnIndex == 0){
	            adatoktop.setnev((String) aValue);
	        }else if(columnIndex == 1){
	            adatoktop.setnehezseg((String) aValue);
	        }else if(columnIndex == 2) {
	        	adatoktop.setido((Integer) aValue);
	        }
	    }
	  /*BETOLTI A HALLGATOI ADATOKAT*/
	  public void addadatoktoplistaba(String nev, String nehezseg, int ido) {
	        adatok.add(new adatoktoplistaba(nev, nehezseg, ido));
	        fireTableRowsInserted(0, adatok.size() - 1);
	    }
}
