package minesweeper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.awt.GridLayout;

import org.junit.Test;

public class teszt {
	menu menuteszt = new menu();
	toplista tp = new toplista(menuteszt.data);
	Game game = new Game(menuteszt.data, "Tesztnev");
	HardGame hgame = new HardGame(menuteszt.data, "Tesztnev");
	Handler handler = new Handler(menuteszt.data, "Tesztnev");
	Grid grid = new Grid(new GridLayout(game.GRIDSIZE, game.GRIDSIZE), handler);
	adatokData tesztdata = menuteszt.returndata();
	
	@Test
	public void dataimportteszt()
	{
		
		assertNotNull(menuteszt.returndata());
		
	}
	
	@Test
	public void checkflagged()
	{
		Cell cell = new Cell(1,1, false, false, handler);
		handler.rightClick(cell);
		assertTrue(cell.isFlagged());
	}
	
	@Test
	public void chekcbomb()
	{	Cell cell = new Cell(1,1, false, false, handler);
		assertEquals(1,cell.getType());
		
	}
	
	@Test
	public void clickbomb()
	{
		Cell cell = new Cell(1,1, false, false, handler);
		handler.click(cell);
		assertFalse(handler.getWon());
	}
	
	@Test
	public void checkEmpty()
	{
	Cell cell = new Cell(0,10, false, false, handler);
	assertEquals(0,cell.getType());
	}
	
	@Test
	public void checkNumber()
	{
	Cell cell = new Cell(2,50, false, false, handler);
	assertEquals(2,cell.getType());
	}
	
	@Test
	public void isDiscovered()
	{	int index = (int)(Math.random()*grid.cellGrid.size());
	Cell randomcell = grid.cellGrid.get(index);
	handler.click(randomcell);
		assertTrue(randomcell.isDiscovered());	
	}
	
	@Test
	public void emptyclicked()
	{
	handler.emptyclicked(2);
	boolean empty;
	assertTrue(handler.queue.size() > 0);
	}
	
	@Test
	public void addTestplayer()
	{	
		tesztdata.addadatoktoplistaba("Teszt Istvan", "Konnyu", 300);
		assertEquals("Teszt Istvan", tesztdata.getValueAt(tesztdata.getRowCount()-1, 0));
	}
	
	@Test
	public void gameEnd()
	{	String jatekvege = "";
		int index = (int)(Math.random()*grid.cellGrid.size());
		Cell randomcell = grid.cellGrid.get(index);
		handler.click(randomcell);
		if(randomcell.getType() == 0)
			jatekvege = "Siker";
		if(handler.getWon())
				jatekvege = "Siker";
		if(!handler.getWon())
			jatekvege = "Siker";
		assertEquals(jatekvege, "Siker");
	}
	
	@Test
	public void testTime()
	{	Cell cell = new Cell(1,1, false, false, handler);
		handler.click(cell);
		assertNotNull(handler.getTimepassed());
	}
	
	@Test
	public void Flag()
	{
		int index = (int)(Math.random()*grid.cellGrid.size());
		Cell randomcell = grid.cellGrid.get(index);
		randomcell.setFlagged(true);
		assertTrue(randomcell.isFlagged());
	}
	
	@Test
	public void testGridsizes()
	{	
		assertTrue(game.GRIDSIZE> 0);
	}
	
}
