package minesweeper;

import java.util.Date;

public class Game { //a könnyű játék osztálya

    public static final int WIDTH = 720, HEIGHT = 720;
    public static final int GRIDSIZE = 5; // 5 a pályaméret (5*5)-ös lesz a páya
    public static final int MINECOUNT = (int) Math.round(GRIDSIZE * GRIDSIZE * .1); //aknaszám a pályaméret alapján 
    //Date date = new Date();

    //private Handler handler = new Handler();

    public Game(adatokData data, String nev) {
    	Handler handler = new Handler(data, nev);
        new Window(WIDTH, HEIGHT, GRIDSIZE, "Aknakereso - ", this, handler);
        Window.update(0);
    }

 
}