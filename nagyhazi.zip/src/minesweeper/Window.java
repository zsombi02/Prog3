package minesweeper;

import javax.swing.*;
import java.awt.*;

public class Window {

    private static JFrame frame;
    static String title;

    public Window(int width, int height, int gridSize, String title, Game game, Handler handler) {
        Window.title = title;
        setFrame(new JFrame(title));

        getFrame().setPreferredSize(new Dimension(width, height));
        getFrame().setMinimumSize(new Dimension(width, height));
        getFrame().setMaximumSize(new Dimension(width, height));
        getFrame().setResizable(false);
        getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getFrame().setLocationRelativeTo(null);

        JPanel panel = new Grid(new GridLayout(gridSize, gridSize), handler);

        getFrame().setContentPane(panel);
        getFrame().pack();

        getFrame().setVisible(true);
    }

    public static void update(int flagged) {
        getFrame().setTitle(title + "Mines: " + Game.MINECOUNT + " - Flags: " + flagged);
    }

	public static JFrame getFrame() {
		return frame;
	}

	public static void setFrame(JFrame frame) {
		Window.frame = frame;
	}

	
}