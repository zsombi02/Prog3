package minesweeper;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JPanel;

public class HardGrid extends JPanel {

	private int bound = HardGame.GRIDSIZE * HardGame.GRIDSIZE;

    private boolean picked = false;

    private ArrayList<Integer> mines = new ArrayList<Integer>();

    public static ArrayList<HardCell> cellGrid = new ArrayList<HardCell>();

    public HardGrid(GridLayout g, HardHandler h) {
        super(g);
        createCells(h);
        addCells();
    }

    public void createCells(HardHandler h) {
        for(int i = 1; i <= HardGame.MINECOUNT; i++) {
            while(!picked) {
                int minePosition = (int) (Math.random() * bound);
                if (!mines.contains(minePosition)) {
                    mines.add(minePosition);
                    picked = true;
                }
            }
            picked = false;
        }

        for(int i = 0; i < bound; i++) {
            if(mines.contains(i)) {
                cellGrid.add(new HardCell(1, i, false, false, h));
            } else if(i % HardGame.GRIDSIZE == 0){
                if(mines.contains(i - HardGame.GRIDSIZE) ||
                        mines.contains(i - HardGame.GRIDSIZE + 1) ||
                        mines.contains(i + 1) ||
                        mines.contains(i + HardGame.GRIDSIZE) ||
                        mines.contains(i + HardGame.GRIDSIZE + 1)) {
                    cellGrid.add(new HardCell(2, i, false, false, h));
                } else {
                    cellGrid.add(new HardCell(0, i, false, false, h));
                }
            } else if(i % HardGame.GRIDSIZE == HardGame.GRIDSIZE - 1){
                if(mines.contains(i - HardGame.GRIDSIZE - 1) ||
                        mines.contains(i - HardGame.GRIDSIZE) ||
                        mines.contains(i - 1) ||
                        mines.contains(i + HardGame.GRIDSIZE - 1) ||
                        mines.contains(i + HardGame.GRIDSIZE)) {
                    cellGrid.add(new HardCell(2, i, false, false, h));
                } else {
                    cellGrid.add(new HardCell(0, i, false, false, h));
                }
            }else {
                if(mines.contains(i - HardGame.GRIDSIZE - 1) ||
                        mines.contains(i - HardGame.GRIDSIZE) ||
                        mines.contains(i - HardGame.GRIDSIZE + 1) ||
                        mines.contains(i - 1) ||
                        mines.contains(i + 1) ||
                        mines.contains(i + HardGame.GRIDSIZE - 1) ||
                        mines.contains(i + HardGame.GRIDSIZE) ||
                        mines.contains(i + HardGame.GRIDSIZE + 1)) {
                    cellGrid.add(new HardCell(2, i, false, false, h));
                } else {
                    cellGrid.add(new HardCell(0, i, false, false, h));
                }
            }
        }
    }

    private void addCells() {
        for(int i = 0; i < cellGrid.size(); i++) {
            add(cellGrid.get(i));
        }
    }
}
