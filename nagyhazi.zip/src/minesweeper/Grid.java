package minesweeper;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Grid extends JPanel {

    private int bound = Game.GRIDSIZE * Game.GRIDSIZE; //a pálya mérete

    private boolean picked = false; //még nem választották azt a mezőt

    private ArrayList<Integer> mines = new ArrayList<Integer>();

    public static ArrayList<Cell> cellGrid = new ArrayList<Cell>();

    public Grid(GridLayout g, Handler h) {  //maga a pálya
        super(g);
        createCells(h);
        addCells();
    }

    public void createCells(Handler h) { //a mezők létrehozása
        for(int i = 1; i <= Game.MINECOUNT; i++) {
            while(!picked) { //még nem lett rákattintva
                int minePosition = (int) (Math.random() * bound); //random szam, addig amig az egyedi, egyedi aknak lesznek
                if (!mines.contains(minePosition)) {  //ne legyen ismétlődő szám
                    mines.add(minePosition); //egyedi az értéke, ha ide jut
                    picked = true;
                }
            }
            picked = false;
        }

        for(int i = 0; i < bound; i++) {
            if(mines.contains(i)) { //akna van ott
                cellGrid.add(new Cell(1, i, false, false, h)); //új mező, 1 típús, mert akna mezőt adok hozzá
            } else if(i % Game.GRIDSIZE == 0){ //mod-os osztás, ha ==0, a bal szelen vagyok, tole balra koordinatak nem kellenek
                if(mines.contains(i - Game.GRIDSIZE) || //folotte telibe
                        mines.contains(i - Game.GRIDSIZE + 1) || //folotte jobbra
                        mines.contains(i + 1) ||
                        mines.contains(i + Game.GRIDSIZE) || //telibe alatta
                        mines.contains(i + Game.GRIDSIZE + 1)) {
                    cellGrid.add(new Cell(2, i, false, false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, h));
                }
            } else if(i % Game.GRIDSIZE == Game.GRIDSIZE - 1){ //jobb szelen vagyok, jobbra nem kell
                if(mines.contains(i - Game.GRIDSIZE - 1) || //folotte balra
                        mines.contains(i - Game.GRIDSIZE) ||
                        mines.contains(i - 1) ||
                        mines.contains(i + Game.GRIDSIZE - 1) || //alatta balra
                        mines.contains(i + Game.GRIDSIZE)) {
                    cellGrid.add(new Cell(2, i, false, false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, h));
                }
            }else {
                if(mines.contains(i - Game.GRIDSIZE - 1) || //folotte balra
                        mines.contains(i - Game.GRIDSIZE) || //folotte telibe
                        mines.contains(i - Game.GRIDSIZE + 1) || //folotte jobbra
                        mines.contains(i - 1) || //balra tole
                        mines.contains(i + 1) ||
                        mines.contains(i + Game.GRIDSIZE - 1) ||//alatta balra
                        mines.contains(i + Game.GRIDSIZE) ||//telibe alatta
                        mines.contains(i + Game.GRIDSIZE + 1)) {
                    cellGrid.add(new Cell(2, i, false, false, h));
                } else {
                    cellGrid.add(new Cell(0, i, false, false, h));
                }
            }
        }
    }

    private void addCells() {
        for(int i = 0; i < cellGrid.size(); i++) {
            add(cellGrid.get(i)); //a JPanelhez hozzaadom az osszes gombot
        }
    }
}