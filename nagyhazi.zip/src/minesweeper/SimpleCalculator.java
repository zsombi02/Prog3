package minesweeper;

public class SimpleCalculator {
	
	public int add (int numberA, int numberB) {
		return numberA + numberB;
	}

}
