package minesweeper;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class gratulalok implements ActionListener {
	
	JFrame frame;
	JButton ok;
	JLabel felirat;
	//Handler handler = new Handler();
	
	public gratulalok(adatokData data, String nev, boolean won, long timepassed, String diff)
	{
	//boolean hadWon = handler.getWon();
	//long timepassed = handler.getTimepassed();
	//System.out.println(timepassed);
	//System.out.println(won);
	//System.out.println(jv.jatekos.getnev());
	
	
	frame  = new JFrame();
	
	ok = new JButton("Ok");
	ok.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Window.getFrame().dispose();
				//menu menu = new menu();
				
				System.out.println(nev);
				data.addadatoktoplistaba(nev, diff, (int)timepassed/1000);
					
				}
});
	
	if( won == true)
	felirat = new JLabel ("Gratulálok! A te időd:" + (int)timepassed/1000);
	else
	felirat = new JLabel ("Vesztettél:(");
	JPanel panel = new JPanel();
	panel.setBorder(BorderFactory.createEmptyBorder(70,70,70,70));
	
	panel.setLayout(new GridLayout(0,1));
	panel.add(felirat);
	panel.add(ok);
	
	frame.add(panel, BorderLayout.CENTER);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setTitle("Eredmeny");
	frame.pack();
	frame.setVisible(true);	
	
}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

