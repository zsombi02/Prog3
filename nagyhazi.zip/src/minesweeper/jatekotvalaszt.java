package minesweeper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class jatekotvalaszt implements ActionListener {
	JFrame frame;
	JButton konnyu;
	JButton normal;

	JLabel felirat;
	JTextField nevbekero;
	//public adatoktoplistaba jatekos = new adatoktoplistaba("", "", 0);
	
	public jatekotvalaszt(adatokData dataa)
	{
		//adatokData data = dataa;
		frame  = new JFrame();
		
		JButton konnyu = new JButton("konnyu");
		konnyu.addActionListener(new ActionListener()
				{
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						if(!nevbekero.getText().equals(""))
						{frame.setVisible(false);
						frame.dispose();
						Game Game = new Game(dataa, nevbekero.getText());
						//player.setnev(nevbekero.getText());
						}
					}	
				}
		);
		
	    JButton normal = new JButton("normal");
	    normal.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame.dispose();
				HardGame HardGame = new HardGame(dataa, nevbekero.getText());
			}
	    });
		
		nevbekero = new JTextField();
		felirat = new JLabel("add meg a nevet!");
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
		panel.setLayout(new GridLayout(0,1));
		panel.add(felirat);
		panel.add(nevbekero);
		panel.add(konnyu);
		panel.add(normal); 
	
		frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Aknakereso");
		frame.pack();
		frame.setVisible(true);		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	}
		
}