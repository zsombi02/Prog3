package minesweeper;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


public class menu extends JFrame implements ActionListener  {
	
	JFrame frame;
	JButton jatek;
	JButton toplista;
	
	JMenu menum;
	JMenuItem kilep, start;
	JMenuBar m;
	adatokData data;
	//player player = new player("","",0);
	
	public adatokData returndata()
	{
		return this.data;
	}
	
	public menu() {
		
		
		 addWindowListener(new WindowAdapter() {
	            @Override
	            public void windowClosing(WindowEvent e) {
	                try {
	                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("toplista.txt"));
	                    oos.writeObject(data.adatok);
	                    oos.close();
	                } catch(Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        });
		 
		 
		 try {
	            data = new adatokData();
	            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("toplista.txt"));
	            data.adatok = (List<adatoktoplistaba>)ois.readObject();
	            //data.addadatoktoplistaba("Imre", 5, 1000);
	            ois.close();
	            
	        } catch(Exception ex) {
	            ex.printStackTrace();
	        }

		 
		frame  = new JFrame();
		
		m = new JMenuBar();
		menum = new JMenu("Menu");
		
		kilep = new JMenuItem("Kilépés");
		kilep.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						frame.dispose();
						System.exit(0);
					}
				}
				);
		
		start = new JMenuItem("Start");
		start.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						jatekotvalaszt jatekotvalaszt= new jatekotvalaszt(data);

					}
				}
				);
		
		JButton jatek = new JButton("Játék");
		jatek.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						jatekotvalaszt jatekotvalaszt= new jatekotvalaszt(data);
			
					}
				}
		);
		
		 JButton toplista = new JButton("Toplista");
		    toplista.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					toplista sf = new toplista(data);
			        sf.setVisible(true);

				}
		    });
		    
		    JPanel panel = new JPanel();
			panel.setBorder(BorderFactory.createEmptyBorder(60,60,60,60));
			panel.setLayout(new GridLayout(0,1));
			panel.add(start);
			panel.add(kilep);
			panel.add(jatek);
			panel.add(toplista); 
			
			
			frame.add(panel, BorderLayout.CENTER);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setTitle("Aknakereso");
			frame.pack();
			frame.setLayout(null);
			frame.setVisible(true);	
			
		
			 
}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
